import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // API routes
  // Get all courses
  app.get("/api/courses", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      next(error);
    }
  });
  
  // Get a specific course
  app.get("/api/courses/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      next(error);
    }
  });
  
  // Get assignments for a course
  app.get("/api/courses/:id/assignments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const courseId = parseInt(req.params.id);
      const assignments = await storage.getAssignmentsByCourse(courseId);
      
      res.json(assignments);
    } catch (error) {
      next(error);
    }
  });
  
  // Get all upcoming assignments (sorted by due date)
  app.get("/api/assignments/upcoming", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const assignments = await storage.getUpcomingAssignments(limit);
      
      res.json(assignments);
    } catch (error) {
      next(error);
    }
  });
  
  // Get recent announcements
  app.get("/api/announcements/recent", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const announcements = await storage.getRecentAnnouncements(limit);
      
      res.json(announcements);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
