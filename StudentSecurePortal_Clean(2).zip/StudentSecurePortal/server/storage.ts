import { 
  users, type User, type InsertUser, 
  courses, type Course, type InsertCourse,
  assignments, type Assignment, type InsertAssignment,
  announcements, type Announcement, type InsertAnnouncement
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserTwoFactorSecret(userId: number, secret: string): Promise<User>;
  enableTwoFactor(userId: number): Promise<User>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Assignment operations
  getAssignments(): Promise<Assignment[]>;
  getAssignmentsByCourse(courseId: number): Promise<Assignment[]>;
  getUpcomingAssignments(limit: number): Promise<Assignment[]>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  
  // Announcement operations
  getAnnouncements(): Promise<Announcement[]>;
  getRecentAnnouncements(limit: number): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private assignments: Map<number, Assignment>;
  private announcements: Map<number, Announcement>;
  
  private userIdCounter: number;
  private courseIdCounter: number;
  private assignmentIdCounter: number;
  private announcementIdCounter: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.assignments = new Map();
    this.announcements = new Map();
    
    this.userIdCounter = 1;
    this.courseIdCounter = 1;
    this.assignmentIdCounter = 1;
    this.announcementIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with some default data
    this.initializeData();
  }

  private initializeData() {
    // Add sample courses
    const courses = [
      { code: "CS", name: "CS 301: Data Structures", instructor: "Dr. Sarah Williams", schedule: "Mon, Wed, Fri 10:00 AM", progress: 92 },
      { code: "MA", name: "MATH 204: Linear Algebra", instructor: "Prof. Robert Chen", schedule: "Tue, Thu 1:30 PM", progress: 88 },
      { code: "PH", name: "PHYS 202: Electricity & Magnetism", instructor: "Dr. James Parker", schedule: "Mon, Wed 2:00 PM", progress: 75 },
      { code: "EN", name: "ENGL 101: Composition", instructor: "Prof. Lisa Thompson", schedule: "Tue, Thu 10:30 AM", progress: 91 },
      { code: "HI", name: "HIST 105: World History", instructor: "Dr. Michael Lee", schedule: "Mon, Wed, Fri 11:30 AM", progress: 79 }
    ];
    
    courses.forEach(course => {
      this.createCourse(course);
    });
    
    // Add sample assignments
    const assignments = [
      { courseId: 2, title: "Linear Algebra Problem Set", dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000) },
      { courseId: 1, title: "Data Structures Project", dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) },
      { courseId: 4, title: "Essay Draft", dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000) }
    ];
    
    assignments.forEach(assignment => {
      this.createAssignment(assignment);
    });
    
    // Add sample announcements
    const announcements = [
      { 
        title: "Library Hours Extended",
        content: "The university library will extend its hours during finals week, remaining open until 2 AM from May 10-17.", 
        date: new Date(Date.now() - 1 * 60 * 60 * 1000) // 1 hour ago
      },
      { 
        title: "CS 301 Midterm Date Change",
        content: "The midterm exam for CS 301 has been rescheduled to Wednesday, March 15th. Please adjust your study plans accordingly.",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
      },
      { 
        title: "Summer Registration Open",
        content: "Registration for summer courses is now open. Please consult with your advisor before April 15th to plan your schedule.",
        date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
      }
    ];
    
    announcements.forEach(announcement => {
      this.createAnnouncement(announcement);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id, 
      twoFactorSecret: null, 
      twoFactorEnabled: false 
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserTwoFactorSecret(userId: number, secret: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, twoFactorSecret: secret };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async enableTwoFactor(userId: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, twoFactorEnabled: true };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  // Course operations
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async createCourse(course: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const newCourse: Course = { ...course, id };
    this.courses.set(id, newCourse);
    return newCourse;
  }
  
  // Assignment operations
  async getAssignments(): Promise<Assignment[]> {
    return Array.from(this.assignments.values());
  }
  
  async getAssignmentsByCourse(courseId: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(
      assignment => assignment.courseId === courseId
    );
  }
  
  async getUpcomingAssignments(limit: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values())
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
      .slice(0, limit);
  }
  
  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const id = this.assignmentIdCounter++;
    const newAssignment: Assignment = { ...assignment, id };
    this.assignments.set(id, newAssignment);
    return newAssignment;
  }
  
  // Announcement operations
  async getAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values());
  }
  
  async getRecentAnnouncements(limit: number): Promise<Announcement[]> {
    return Array.from(this.announcements.values())
      .sort((a, b) => b.date.getTime() - a.date.getTime())
      .slice(0, limit);
  }
  
  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const id = this.announcementIdCounter++;
    const newAnnouncement: Announcement = { ...announcement, id };
    this.announcements.set(id, newAnnouncement);
    return newAnnouncement;
  }
}

export const storage = new MemStorage();
