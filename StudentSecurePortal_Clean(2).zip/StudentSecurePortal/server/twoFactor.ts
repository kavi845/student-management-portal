import speakeasy from "speakeasy";
import { promisify } from "util";
import { randomBytes } from "crypto";

const randomBytesAsync = promisify(randomBytes);

export async function generateTwoFactorSecret(email: string): Promise<string> {
  // Generate a new secret for the user
  const secret = speakeasy.generateSecret({
    length: 20,
    name: `Student Portal:${email}`,
    issuer: "Student Portal"
  });
  
  // Return the base32 encoded secret
  return secret.base32;
}

export function generateTotpUri(secret: string, email: string): string {
  return speakeasy.otpauthURL({
    secret,
    label: encodeURIComponent(`Student Portal:${email}`),
    issuer: "Student Portal",
    encoding: "base32"
  });
}

export function validateTwoFactorToken(secret: string, token: string): boolean {
  return speakeasy.totp.verify({
    secret,
    encoding: "base32",
    token,
    window: 1 // Allow 1 time step before and after (for clock skew)
  });
}

// Generate a temporary secret for email-based 2FA
export async function generateEmailCode(): Promise<string> {
  // Generate a 6-digit numeric code
  const bytes = await randomBytesAsync(3);
  const code = parseInt(bytes.toString("hex"), 16) % 1000000;
  
  // Ensure code is 6 digits with leading zeros
  return code.toString().padStart(6, "0");
}
