import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/dashboard/header";
import { Sidebar } from "@/components/dashboard/sidebar";
import { QuickStats } from "@/components/dashboard/quick-stats";
import { CoursesList } from "@/components/dashboard/courses-list";
import { Announcements } from "@/components/dashboard/announcements";
import { UpcomingDeadlines } from "@/components/dashboard/upcoming-deadlines";
import { useAuth } from "@/hooks/use-auth";
import { Course, Assignment, Announcement } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();
  
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });
  
  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements/recent"],
    enabled: !!user,
  });
  
  const { data: assignments = [] } = useQuery<Assignment[]>({
    queryKey: ["/api/assignments/upcoming"],
    enabled: !!user,
  });
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-bg">
      <Header />
      
      <div className="flex-grow flex">
        <Sidebar />
        
        <div className="flex-1 md:ml-64 overflow-x-hidden">
          <main className="py-6 px-4 sm:px-6 lg:px-8">
            <div className="mb-6 relative overflow-hidden rounded-lg">
              <img 
                src="/images/dashboard-banner.svg" 
                alt="Dashboard Banner" 
                className="w-full h-auto object-cover" 
              />
              <div className="absolute inset-0 flex flex-col justify-center px-6 bg-gradient-to-r from-primary/80 to-transparent">
                <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
                <p className="text-white/90 max-w-md">
                  Welcome back, {user?.fullName}! Here's what's happening with your courses.
                </p>
              </div>
            </div>
            
            <QuickStats 
              courseCount={courses.length}
              upcomingDeadlinesCount={assignments.length}
              unreadMessagesCount={7}
              gpa={3.7}
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <CoursesList courses={courses} />
              </div>
              
              <div className="lg:col-span-1">
                <Announcements announcements={announcements} />
                <UpcomingDeadlines assignments={assignments} courses={courses} />
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
