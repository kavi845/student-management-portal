import { useState } from "react";
import { Redirect } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { LoginForm } from "@/components/auth/login-form";
import { RegisterForm } from "@/components/auth/register-form";
import { TwoFactorModal } from "@/components/auth/two-factor-modal";
import { InfoIcon } from "lucide-react";

export default function AuthPage() {
  const { user, loginMutation } = useAuth();
  const [showTwoFactorModal, setShowTwoFactorModal] = useState(false);
  const [twoFactorData, setTwoFactorData] = useState<{ email: string } | null>(null);
  
  // If already logged in, redirect to dashboard
  if (user) {
    return <Redirect to="/" />;
  }
  
  // Watch for 2FA requirement from login mutation
  if (loginMutation.data && 'requiresTwoFactor' in loginMutation.data && !showTwoFactorModal) {
    setTwoFactorData({
      email: loginMutation.data.email as string
    });
    setShowTwoFactorModal(true);
  }
  
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-neutral-bg">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 md:p-8">
          <div className="text-center mb-6">
            <h1 className="text-primary text-2xl font-bold">Student Portal</h1>
            <p className="text-neutral-muted mt-2">Sign in to access your academic resources</p>
          </div>
          
          <Tabs defaultValue="login">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <LoginForm setShowTwoFactorModal={setShowTwoFactorModal} />
            </TabsContent>
            
            <TabsContent value="register">
              <RegisterForm />
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="bg-blue-50 p-4 border-t border-blue-100">
          <div className="flex items-start">
            <InfoIcon className="h-5 w-5 text-primary flex-shrink-0 mr-3" />
            <p className="text-sm text-neutral-text">
              This portal uses two-factor authentication to protect your account. Have your phone ready.
            </p>
          </div>
        </div>
      </div>
      
      {showTwoFactorModal && twoFactorData && (
        <TwoFactorModal 
          email={twoFactorData.email}
          isOpen={showTwoFactorModal}
          onClose={() => setShowTwoFactorModal(false)}
        />
      )}
    </div>
  );
}
