import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Assignment, Course } from "@shared/schema";
import { formatRelativeTime, getDueDateColor } from "@/lib/utils";

interface UpcomingDeadlinesProps {
  assignments: Assignment[];
  courses: Course[];
}

export function UpcomingDeadlines({ assignments, courses }: UpcomingDeadlinesProps) {
  // Function to get course name by ID
  const getCourseName = (courseId: number): string => {
    const course = courses.find(c => c.id === courseId);
    return course ? course.code : "Unknown";
  };
  
  // Format the due date to a human-readable string
  const formatDueDate = (dueDate: Date): string => {
    const now = new Date();
    const diffInDays = Math.ceil((new Date(dueDate).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays <= 0) return "Due Today";
    if (diffInDays === 1) return "Due Tomorrow";
    if (diffInDays <= 3) return `Due in ${diffInDays} days`;
    return formatRelativeTime(new Date(dueDate));
  };

  return (
    <Card className="mt-6">
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-neutral-text">
          Upcoming Deadlines
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {assignments.length === 0 ? (
          <div className="px-6 py-8 flex flex-col items-center justify-center">
            <img 
              src="/images/assignments-illustration.svg" 
              alt="No deadlines" 
              className="w-40 h-40 mb-4" 
            />
            <p className="text-center text-neutral-muted">
              No upcoming deadlines.
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {assignments.map((assignment) => (
              <li key={assignment.id} className="px-6 py-4">
                <div className="flex justify-between">
                  <div>
                    <p className="text-sm font-medium text-neutral-text">
                      {assignment.title}
                    </p>
                    <p className="text-xs text-neutral-muted mt-1">
                      {getCourseName(assignment.courseId)}
                    </p>
                  </div>
                  <div className="flex items-center">
                    <span className={`text-xs font-medium ${getDueDateColor(new Date(assignment.dueDate))}`}>
                      {formatDueDate(new Date(assignment.dueDate))}
                    </span>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
      <CardFooter className="border-t border-gray-200 px-6 py-3">
        <div className="text-sm">
          <Link href="/assignments">
            <a className="font-medium text-primary hover:text-primary-light">
              View all deadlines
            </a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
