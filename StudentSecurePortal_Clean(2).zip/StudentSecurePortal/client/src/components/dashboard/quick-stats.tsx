import { Link } from "wouter";
import {
  BookOpenIcon,
  ClockIcon,
  ClipboardCheckIcon,
  MessageSquareIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface QuickStatsProps {
  courseCount: number;
  upcomingDeadlinesCount: number;
  gpa: number;
  unreadMessagesCount: number;
}

export function QuickStats({
  courseCount,
  upcomingDeadlinesCount,
  gpa,
  unreadMessagesCount,
}: QuickStatsProps) {
  const stats = [
    {
      name: "Active Courses",
      value: courseCount,
      icon: BookOpenIcon,
      iconColor: "bg-primary-light",
      linkText: "View all courses",
      linkHref: "/courses",
    },
    {
      name: "Upcoming Deadlines",
      value: upcomingDeadlinesCount,
      icon: ClockIcon,
      iconColor: "bg-accent",
      linkText: "View all deadlines",
      linkHref: "/assignments",
    },
    {
      name: "Current GPA",
      value: gpa.toFixed(1),
      icon: ClipboardCheckIcon,
      iconColor: "bg-secondary",
      linkText: "View academic record",
      linkHref: "/grades",
    },
    {
      name: "Unread Messages",
      value: unreadMessagesCount,
      icon: MessageSquareIcon,
      iconColor: "bg-status-error",
      linkText: "View all messages",
      linkHref: "/messages",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
      {stats.map((stat) => (
        <Card key={stat.name} className="overflow-hidden">
          <CardContent className="p-0">
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 ${stat.iconColor} rounded-md p-3`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-neutral-muted truncate">
                      {stat.name}
                    </dt>
                    <dd>
                      <div className="text-lg font-semibold text-neutral-text">
                        {stat.value}
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
            <div className="bg-neutral-bg px-5 py-3">
              <div className="text-sm">
                <Link href={stat.linkHref}>
                  <a className="font-medium text-primary hover:text-primary-light">
                    {stat.linkText}
                  </a>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
