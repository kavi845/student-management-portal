import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Course } from "@shared/schema";
import { cn, getInitials } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface CoursesListProps {
  courses: Course[];
}

export function CoursesList({ courses }: CoursesListProps) {
  const getProgressColor = (progress: number): string => {
    if (progress >= 90) return "bg-green-100 text-green-800";
    if (progress >= 80) return "bg-green-100 text-green-800";
    if (progress >= 70) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  return (
    <Card>
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-neutral-text">
          Your Courses
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ul className="divide-y divide-gray-200">
          {courses.length === 0 ? (
            <li className="px-6 py-8">
              <div className="flex flex-col items-center justify-center">
                <img 
                  src="/images/course-illustration.svg" 
                  alt="No courses" 
                  className="w-40 h-40 mb-4" 
                />
                <p className="text-center text-neutral-muted">
                  You haven't enrolled in any courses yet.
                </p>
              </div>
            </li>
          ) : (
            courses.map((course) => (
              <li key={course.id}>
                <div className="px-6 py-4 flex items-center">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center">
                      <div className={cn(
                        "h-10 w-10 rounded-full flex items-center justify-center text-white font-bold",
                        course.code === "CS" ? "bg-primary-light" :
                        course.code === "MA" ? "bg-accent-dark" :
                        course.code === "PH" ? "bg-secondary-dark" :
                        course.code === "EN" ? "bg-status-error" :
                        course.code === "HI" ? "bg-purple-600" :
                        "bg-primary"
                      )}>
                        {course.code}
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-neutral-text">
                          {course.name}
                        </p>
                        <p className="text-sm text-neutral-muted">
                          {course.instructor} • {course.schedule}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="ml-4 flex-shrink-0">
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "px-2 text-xs leading-5 font-semibold rounded-full",
                        getProgressColor(course.progress)
                      )}
                    >
                      {course.progress}%
                    </Badge>
                  </div>
                </div>
              </li>
            ))
          )}
        </ul>
      </CardContent>
    </Card>
  );
}
