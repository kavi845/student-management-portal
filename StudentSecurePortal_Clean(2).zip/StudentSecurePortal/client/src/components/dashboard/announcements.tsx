import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Announcement } from "@shared/schema";
import { formatRelativeTime } from "@/lib/utils";

interface AnnouncementsProps {
  announcements: Announcement[];
}

export function Announcements({ announcements }: AnnouncementsProps) {
  return (
    <Card>
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-neutral-text">
          Announcements
        </CardTitle>
      </CardHeader>
      <CardContent className="px-6 py-5">
        {announcements.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4">
            <img 
              src="/images/announcements-illustration.svg" 
              alt="No announcements" 
              className="w-40 h-40 mb-4" 
            />
            <p className="text-center text-neutral-muted">
              No announcements available.
            </p>
          </div>
        ) : (
          <ul className="space-y-5">
            {announcements.map((announcement, index) => (
              <li 
                key={announcement.id}
                className={index < announcements.length - 1 ? "pb-5 border-b border-gray-200" : ""}
              >
                <div className="relative">
                  <span className="text-xs text-neutral-muted">
                    {formatRelativeTime(new Date(announcement.date))}
                  </span>
                  <h4 className="text-sm font-medium text-neutral-text mt-1">
                    {announcement.title}
                  </h4>
                  <p className="text-sm text-neutral-muted mt-1">
                    {announcement.content}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
      <CardFooter className="border-t border-gray-200 px-6 py-3">
        <div className="text-sm">
          <Link href="/announcements">
            <a className="font-medium text-primary hover:text-primary-light">
              View all announcements
            </a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
