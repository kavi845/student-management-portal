import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  HomeIcon,
  BookOpenIcon,
  ClipboardCheckIcon,
  BarChartIcon,
  CalendarIcon,
  MessageSquareIcon,
  UserIcon,
  SettingsIcon,
  LogOutIcon,
} from "lucide-react";

export function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  if (!user) return null;
  
  const navigation = [
    { name: "Dashboard", href: "/", icon: HomeIcon, current: location === "/" },
    { name: "Courses", href: "/courses", icon: BookOpenIcon, current: location === "/courses" },
    { name: "Assignments", href: "/assignments", icon: ClipboardCheckIcon, current: location === "/assignments" },
    { name: "Grades", href: "/grades", icon: BarChartIcon, current: location === "/grades" },
    { name: "Calendar", href: "/calendar", icon: CalendarIcon, current: location === "/calendar" },
    { name: "Messages", href: "/messages", icon: MessageSquareIcon, current: location === "/messages" },
  ];
  
  const accountNavigation = [
    { name: "Profile", href: "/profile", icon: UserIcon, current: location === "/profile" },
    { name: "Settings", href: "/settings", icon: SettingsIcon, current: location === "/settings" },
  ];
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div 
      className={cn(
        "bg-white w-64 shadow-md fixed h-full z-30 inset-y-0 left-0 transform transition duration-200 ease-in-out",
        isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}
    >
      <div className="h-full flex flex-col">
        <div className="p-4 border-b">
          <div className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src="" alt="Profile" />
              <AvatarFallback>{user.fullName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-text">{user.fullName}</p>
              <p className="text-xs text-neutral-muted">Student ID: {user.studentId}</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 overflow-y-auto">
          <ul className="p-2 space-y-1">
            {navigation.map((item) => (
              <li key={item.name}>
                <Link href={item.href}>
                  <a
                    className={cn(
                      "flex items-center px-4 py-2 text-sm rounded-md",
                      item.current
                        ? "bg-primary-light text-white font-medium"
                        : "text-neutral-text hover:bg-neutral-bg hover:text-primary"
                    )}
                  >
                    <item.icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
          
          <div className="border-t pt-2 mt-2">
            <ul className="p-2 space-y-1">
              {accountNavigation.map((item) => (
                <li key={item.name}>
                  <Link href={item.href}>
                    <a
                      className={cn(
                        "flex items-center px-4 py-2 text-sm rounded-md",
                        item.current
                          ? "bg-primary-light text-white font-medium"
                          : "text-neutral-text hover:bg-neutral-bg hover:text-primary"
                      )}
                    >
                      <item.icon className="h-5 w-5 mr-3" />
                      {item.name}
                    </a>
                  </Link>
                </li>
              ))}
              <li>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center px-4 py-2 text-sm rounded-md text-neutral-text hover:bg-neutral-bg hover:text-status-error"
                >
                  <LogOutIcon className="h-5 w-5 mr-3" />
                  Logout
                </button>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
}
