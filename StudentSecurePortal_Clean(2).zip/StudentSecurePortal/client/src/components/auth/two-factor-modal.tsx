import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { X, Mail, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { maskEmail } from "@/lib/utils";

interface TwoFactorModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
}

export function TwoFactorModal({ isOpen, onClose, email }: TwoFactorModalProps) {
  const { verifyTwoFactorMutation } = useAuth();
  const [verificationCode, setVerificationCode] = useState<string[]>(["", "", "", "", "", ""]);
  const inputRefs = useRef<HTMLInputElement[]>([]);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds
  
  // Handle countdown timer
  useEffect(() => {
    if (!isOpen) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [isOpen]);
  
  // Format time as mm:ss
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const handleInputChange = (index: number, value: string) => {
    if (!/^[0-9]$/.test(value) && value !== "") return;
    
    const newCode = [...verificationCode];
    newCode[index] = value;
    setVerificationCode(newCode);
    
    // Move to next input if value is entered
    if (value !== "" && index < 5) {
      inputRefs.current[index + 1].focus();
    }
    
    // Submit if all digits are filled
    if (newCode.every(digit => digit !== "") && index === 5) {
      handleSubmit();
    }
  };
  
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Handle backspace
    if (e.key === "Backspace") {
      if (verificationCode[index] === "" && index > 0) {
        inputRefs.current[index - 1].focus();
      }
    }
  };
  
  const handleSubmit = () => {
    const token = verificationCode.join("");
    verifyTwoFactorMutation.mutate({ token });
  };
  
  const handleResendCode = () => {
    // Reset the timer
    setTimeLeft(300);
    // TODO: Implement resend code functionality
  };
  
  if (!isOpen) return null;
  
  // If verification was successful, close the modal
  if (verifyTwoFactorMutation.isSuccess) {
    onClose();
    return null;
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-neutral-text">Two-Factor Authentication</h2>
            <button 
              type="button" 
              className="text-neutral-muted hover:text-neutral-text"
              onClick={onClose}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="mb-6">
            <div className="flex items-center mb-4 text-neutral-text">
              <Mail className="h-5 w-5 text-primary mr-2" />
              <span>Verification code sent to <strong>{maskEmail(email)}</strong></span>
            </div>
            
            <p className="text-sm text-neutral-muted mb-4">
              Enter the 6-digit code from your email or authenticator app.
            </p>
            
            <div className="flex justify-between mb-4 gap-2">
              {verificationCode.map((digit, index) => (
                <input
                  key={index}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleInputChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  ref={(el) => {
                    if (el) inputRefs.current[index] = el;
                  }}
                  className="w-12 h-12 text-center text-xl font-mono border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  autoFocus={index === 0}
                  aria-label={`Digit ${index + 1}`}
                />
              ))}
            </div>
            
            <div className="flex justify-between items-center text-sm">
              <span className="text-neutral-muted">
                Code expires in <span className="text-accent-dark font-medium">{formatTime(timeLeft)}</span>
              </span>
              <button 
                type="button" 
                className="text-primary hover:text-primary-light font-medium"
                onClick={handleResendCode}
              >
                Resend code
              </button>
            </div>
            
            <Button
              className="w-full mt-6"
              disabled={verificationCode.some(digit => digit === "") || verifyTwoFactorMutation.isPending}
              onClick={handleSubmit}
            >
              {verifyTwoFactorMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Verify"
              )}
            </Button>
          </div>
          
          <div className="text-center text-sm">
            <button className="text-primary hover:text-primary-light font-medium">
              Use another verification method
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
